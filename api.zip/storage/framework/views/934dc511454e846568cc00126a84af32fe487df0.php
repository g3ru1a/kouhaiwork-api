<html>
    <body>
        
        <p>This is an email yeah</p>
        <h1></h1>
    </body>
</html><?php /**PATH /home/g3ru1a/Documents/kouhai.work/api/resources/views/test.blade.php ENDPATH**/ ?>